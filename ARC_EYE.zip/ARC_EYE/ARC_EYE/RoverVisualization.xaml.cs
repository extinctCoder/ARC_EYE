﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ARC_EYE
{
    /// <summary>
    /// Interaction logic for RoverVisualization.xaml
    /// </summary>
    public partial class RoverVisualization : UserControl
    {
        public static RoverVisualization _RoverVisualization = null;
        public static RoverVisualization RoverVisualizationHandler()
        {
            if (_RoverVisualization == null)
            {
                _RoverVisualization = new RoverVisualization();
            }
            return _RoverVisualization;
        }
        private RoverVisualization()
        {
            InitializeComponent();
        }
    }
}
