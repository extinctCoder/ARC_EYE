﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Controls;
using SharpDX.DirectInput;
using System.Windows;
using System.Threading;

namespace ARC_EYE
{
    public partial class RoverMovement
    {
        RoverAndArmRoverMovement roverMovement = RoverAndArmRoverMovement.Stop;
        double pwm = 0;
        double tempPwm = 0;
        private DirectInput directInput = new DirectInput();
        private Guid joystickGuid = Guid.Empty;

        public void updatePwm(double pwm)
        {
            _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
            {
                _RoverMovement.pwm = pwm;
                _RoverMovement.pwm_slidr.Value = pwm;
            }));
        }

        public static void KeyboardInputHandler_KeyDown(KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.W)
            {
                if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.Forward)
                {
                    _RoverMovement.rvr_up.Background = Brushes.Green;
                    _RoverMovement.roverMovement = RoverAndArmRoverMovement.Forward;
                    _RoverMovement.pwm = _RoverMovement.tempPwm;
                    _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                    _RoverMovement.RoverMovementStatusUpdater();
                }
                else
                {
                    RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                }
            }
            else if (e.Key == System.Windows.Input.Key.S)
            {
                if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.Backward)
                {
                    _RoverMovement.rvr_dwn.Background = Brushes.Green;
                    _RoverMovement.roverMovement = RoverAndArmRoverMovement.Backward;
                    _RoverMovement.pwm = _RoverMovement.tempPwm;
                    _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                    _RoverMovement.RoverMovementStatusUpdater();
                }
                else
                {
                    RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                }
            }
            else if (e.Key == System.Windows.Input.Key.A)
            {
                if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.LeftTurn)
                {
                    _RoverMovement.rvr_lft.Background = Brushes.Green;
                    _RoverMovement.roverMovement = RoverAndArmRoverMovement.LeftTurn;
                    _RoverMovement.pwm = _RoverMovement.tempPwm;
                    _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                    _RoverMovement.RoverMovementStatusUpdater();
                }
                else
                {
                    RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                }
            }
            else if (e.Key == System.Windows.Input.Key.D)
            {
                if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.RightTurn)
                {
                    _RoverMovement.rvr_rght.Background = Brushes.Green;
                    _RoverMovement.roverMovement = RoverAndArmRoverMovement.RightTurn;
                    _RoverMovement.pwm = _RoverMovement.tempPwm;
                    _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                    _RoverMovement.RoverMovementStatusUpdater();
                }
                else
                {
                    RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                }
            }
            else if (e.Key == System.Windows.Input.Key.Space)
            {
                if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.Stop)
                {
                    _RoverMovement.rvr_rght.Background = Brushes.LightGray;
                    _RoverMovement.rvr_up.Background = Brushes.LightGray;
                    _RoverMovement.rvr_dwn.Background = Brushes.LightGray;
                    _RoverMovement.rvr_lft.Background = Brushes.LightGray;
                    _RoverMovement.roverMovement = RoverAndArmRoverMovement.Stop;
                    _RoverMovement.pwm = 0;
                    _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                    _RoverMovement.RoverMovementStatusUpdater();
                }
                else
                {
                    RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                }
            }
            else if (e.Key == System.Windows.Input.Key.LeftShift)
            {
                if (_RoverMovement.tempPwm <= 80)
                {
                    _RoverMovement.tempPwm = _RoverMovement.tempPwm + 20;
                    RoverConsole.ArcEyeContentThreadSafe("Speed set to : " + _RoverMovement.tempPwm.ToString());
                }
                else
                {
                    RoverConsole.ArcEyeAiContentThreadSafe("Speed Already Set To The Maximum Limit");
                }
            }
            else if (e.Key == System.Windows.Input.Key.LeftCtrl)
            {

                if (_RoverMovement.tempPwm >= 40)
                {
                    _RoverMovement.tempPwm = _RoverMovement.tempPwm - 20;
                    RoverConsole.ArcEyeContentThreadSafe("Speed set to : " + _RoverMovement.tempPwm.ToString());
                }
                else
                {
                    RoverConsole.ArcEyeAiContentThreadSafe("Speed Already Set To The Minimum Limit");
                }
            }
            //e.Handled = true;
        }

        public static void KeyboardInputHandler_KeyUp(KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.W)
            {
                _RoverMovement.rvr_up.Background = Brushes.Red;
                if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.Stop)
                {

                    _RoverMovement.roverMovement = RoverAndArmRoverMovement.Stop;
                    _RoverMovement.pwm = 0;
                    _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                    _RoverMovement.RoverMovementStatusUpdater();
                }
                else
                {
                    RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                }
            }
            else if (e.Key == System.Windows.Input.Key.S)
            {
                _RoverMovement.rvr_dwn.Background = Brushes.Red;
                if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.Stop)
                {
                    _RoverMovement.roverMovement = RoverAndArmRoverMovement.Stop;
                    _RoverMovement.pwm = 0;
                    _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                    _RoverMovement.RoverMovementStatusUpdater();
                }
                else
                {
                    RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                }
            }
            else if (e.Key == System.Windows.Input.Key.A)
            {
                _RoverMovement.rvr_lft.Background = Brushes.Red;
                if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.Stop)
                {
                    _RoverMovement.roverMovement = RoverAndArmRoverMovement.Stop;
                    _RoverMovement.pwm = 0;
                    _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                    _RoverMovement.RoverMovementStatusUpdater();
                }
                else
                {
                    RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                }
            }
            else if (e.Key == System.Windows.Input.Key.D)
            {
                _RoverMovement.rvr_rght.Background = Brushes.Red;
                if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.Stop)
                {
                    _RoverMovement.roverMovement = RoverAndArmRoverMovement.Stop;
                    _RoverMovement.pwm = 0;
                    _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                    _RoverMovement.RoverMovementStatusUpdater();
                }
                else
                {
                    RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                }
            }
            //e.Handled = true;
        }

        public void RoverMovementStatusUpdater()
        {
            if (_RoverMovement != null)
            {
                RoverConsole.ArcEyeAiContentThreadSafe("Rover Movement Command : Direction-" + roverMovement.ToString() + ", Speed-" + pwm.ToString());
                ConnectorOne.RoverMovementStatusUpdater(roverMovement, pwm);
            }
        }

        public void RoverMovementStatusUpdater(RoverAndArmRoverMovement roverMovement, double pwm)
        {
            RoverConsole.ArcEyeAiContent("Rover Movement Command : Direction-" + roverMovement.ToString() + ", Speed-" + pwm.ToString());
            ConnectorOne.RoverMovementStatusUpdater(roverMovement, pwm);
        }

        private void joystickInputHandler(Joystick joystick)
        {
            try
            {
                RoverConsole.ArcEyeContentThreadSafe("Joystick ready to receive command.");
                joystick.Properties.BufferSize = 128;
                joystick.Acquire();
                while (true)
                {
                    joystick.Poll();
                    var datas = joystick.GetBufferedData();
                    foreach (var state in datas)
                    {
                        RoverConsole.ArcEyeContentThreadSafe("Joystick data : " + state.ToString());
                        _RoverMovement.buttonHandlerAnalog(state);
                        _RoverMovement.buttonHandlerDigital(state);
                    }

                }
            }
            catch (Exception ex)
            {
                RoverConsole.ArcEyeAiContentThreadSafe(ex.ToString());
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.joystck_pnl.IsExpanded = false;
                    _RoverMovement.rld_btn.IsEnabled = true;
                    _RoverMovement.fst_initialize_btn.IsEnabled = true;
                    if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.Stop)
                    {
                        RoverConsole.ArcEyeAiContentThreadSafe("Exciting safety procedure ...!!!");
                        _RoverMovement.roverMovement = RoverAndArmRoverMovement.Stop;
                        _RoverMovement.pwm = 0;
                        _RoverMovement.RoverMovementStatusUpdater();
                    }
                }));
                RoverConsole.ArcEyeAiContentThreadSafe("Mouse And KeyBoard Panel Activated, Set As primary I/o Device");
            }
        }


        private void buttonHandlerAnalog(JoystickUpdate state)
        {
            if (state.Offset == JoystickOffset.X && state.Value < 32767)//left Function
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.LeftTurn)
                    {
                        _RoverMovement.xy_rb_13.IsChecked = true;
                        _RoverMovement.pb_x.Value = state.Value / 655.35;
                        _RoverMovement.roverMovement = RoverAndArmRoverMovement.LeftTurn;
                        _RoverMovement.pwm = _RoverMovement.tempPwm;
                        _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                        _RoverMovement.RoverMovementStatusUpdater();
                    }
                    else
                    {
                        RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                    }
                }));
            }
            else if (state.Offset == JoystickOffset.X && state.Value > 32767)//right Function
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.RightTurn)
                    {
                        _RoverMovement.xy_rb_53.IsChecked = true;
                        _RoverMovement.pb_x.Value = state.Value / 655.35;
                        _RoverMovement.roverMovement = RoverAndArmRoverMovement.RightTurn;
                        _RoverMovement.pwm = _RoverMovement.tempPwm;
                        _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                        _RoverMovement.RoverMovementStatusUpdater();
                    }
                    else
                    {
                        RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                    }
                }));
            }
            else if (state.Offset == JoystickOffset.X && state.Value == 32767) //Stop Function
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.Stop)
                    {
                        _RoverMovement.xy_rb_13.IsChecked = false;
                        _RoverMovement.xy_rb_53.IsChecked = false;
                        _RoverMovement.pb_x.Value = state.Value / 655.35;
                        _RoverMovement.roverMovement = RoverAndArmRoverMovement.Stop;
                        _RoverMovement.pwm = 0;
                        _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                        _RoverMovement.RoverMovementStatusUpdater();
                    }
                    else
                    {
                        RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                    }
                }));
            }

            if (state.Offset == JoystickOffset.Y && state.Value < 32767)//forward function
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.Forward)
                    {
                        _RoverMovement.xy_rb_31.IsChecked = true;
                        _RoverMovement.pb_y.Value = state.Value / 655.35;
                        _RoverMovement.roverMovement = RoverAndArmRoverMovement.Forward;
                        _RoverMovement.pwm = _RoverMovement.tempPwm;
                        _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                        _RoverMovement.RoverMovementStatusUpdater();
                    }
                    else
                    {
                        RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                    }
                }));

            }
            else if (state.Offset == JoystickOffset.Y && state.Value > 32767)//backward function
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.Backward)
                    {
                        _RoverMovement.xy_rb_35.IsChecked = true;
                        _RoverMovement.pb_y.Value = state.Value / 655.35;
                        _RoverMovement.roverMovement = RoverAndArmRoverMovement.Backward;
                        _RoverMovement.pwm = _RoverMovement.tempPwm;
                        _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                        _RoverMovement.RoverMovementStatusUpdater();
                    }
                    else
                    {
                        RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                    }
                }));
            }
            else if (state.Offset == JoystickOffset.Y && state.Value == 32767)//Stop Command
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.Stop)
                    {
                        _RoverMovement.xy_rb_31.IsChecked = false;
                        _RoverMovement.xy_rb_35.IsChecked = false;
                        _RoverMovement.pb_y.Value = state.Value / 655.35;
                        _RoverMovement.roverMovement = RoverAndArmRoverMovement.Stop;
                        _RoverMovement.pwm = 0;
                        _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                        _RoverMovement.RoverMovementStatusUpdater();
                    }
                    else
                    {
                        RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                    }
                }));
            }

            if (state.Offset == JoystickOffset.Z && state.Value < 32767)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.zz_rb_13.IsChecked = true;
                    _RoverMovement.pb_z.Value = state.Value / 655.35;
                }));
            }
            else if (state.Offset == JoystickOffset.Z && state.Value > 32767)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.zz_rb_53.IsChecked = true;
                    _RoverMovement.pb_z.Value = state.Value / 655.35;
                }));
            }
            else if (state.Offset == JoystickOffset.Z && state.Value == 32767)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.zz_rb_13.IsChecked = false;
                    _RoverMovement.zz_rb_53.IsChecked = false;
                    _RoverMovement.pb_z.Value = state.Value / 655.35;
                }));
            }

            if (state.Offset == JoystickOffset.RotationZ && state.Value < 32767)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.zz_rb_31.IsChecked = true;
                    _RoverMovement.pb_rz.Value = state.Value / 655.35;
                }));
            }
            else if (state.Offset == JoystickOffset.RotationZ && state.Value > 32767)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.zz_rb_35.IsChecked = true;
                    _RoverMovement.pb_rz.Value = state.Value / 655.35;
                }));
            }
            else if (state.Offset == JoystickOffset.RotationZ && state.Value == 32767)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.zz_rb_31.IsChecked = false;
                    _RoverMovement.zz_rb_35.IsChecked = false;
                    _RoverMovement.pb_rz.Value = state.Value / 655.35;
                }));
            }
        }

        private void buttonHandlerDigital(JoystickUpdate state)
        {
            if (state.Offset == JoystickOffset.PointOfViewControllers0 && state.Value == 27000)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.LeftTurn)
                    {
                        _RoverMovement.rb_povc_left.IsChecked = true;
                        _RoverMovement.roverMovement = RoverAndArmRoverMovement.LeftTurn;
                        _RoverMovement.pwm = _RoverMovement.tempPwm;
                        _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                        _RoverMovement.RoverMovementStatusUpdater();
                    }
                    else
                    {
                        RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                    }
                }));
            }
            else if (state.Offset == JoystickOffset.PointOfViewControllers0 && state.Value == 18000)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.Backward)
                    {

                        _RoverMovement.rb_povc_down.IsChecked = true;
                        _RoverMovement.roverMovement = RoverAndArmRoverMovement.Backward;
                        _RoverMovement.pwm = _RoverMovement.tempPwm;
                        _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                        _RoverMovement.RoverMovementStatusUpdater();
                    }
                    else
                    {
                        RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                    }
                }));
            }
            else if (state.Offset == JoystickOffset.PointOfViewControllers0 && state.Value == 9000)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.RightTurn)
                    {

                        _RoverMovement.rb_povc_right.IsChecked = true;
                        _RoverMovement.roverMovement = RoverAndArmRoverMovement.RightTurn;
                        _RoverMovement.pwm = _RoverMovement.tempPwm;
                        _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                        _RoverMovement.RoverMovementStatusUpdater();
                    }
                    else
                    {
                        RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                    }
                }));
            }
            else if (state.Offset == JoystickOffset.PointOfViewControllers0 && state.Value == 0)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.Forward)
                    {
                        _RoverMovement.rb_povc_up.IsChecked = true;
                        _RoverMovement.roverMovement = RoverAndArmRoverMovement.Forward;
                        _RoverMovement.pwm = _RoverMovement.tempPwm;
                        _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                        _RoverMovement.RoverMovementStatusUpdater();
                    }
                    else
                    {
                        RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                    }
                }));
            }
            else if (state.Offset == JoystickOffset.PointOfViewControllers0 && state.Value == 31500)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    //up left
                }));
            }
            else if (state.Offset == JoystickOffset.PointOfViewControllers0 && state.Value == 4500)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    //up right
                }));
            }
            else if (state.Offset == JoystickOffset.PointOfViewControllers0 && state.Value == 22500)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    //down left
                }));
            }
            else if (state.Offset == JoystickOffset.PointOfViewControllers0 && state.Value == 13500)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    //down right
                }));
            }
            else if (state.Offset == JoystickOffset.PointOfViewControllers0 && state.Value == -1)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    if (_RoverMovement.roverMovement != RoverAndArmRoverMovement.Stop)
                    {
                        _RoverMovement.rb_povc_left.IsChecked = false;
                        _RoverMovement.rb_povc_down.IsChecked = false;
                        _RoverMovement.rb_povc_right.IsChecked = false;
                        _RoverMovement.rb_povc_up.IsChecked = false;
                        _RoverMovement.roverMovement = RoverAndArmRoverMovement.Stop;
                        _RoverMovement.pwm = 0;
                        _RoverMovement.pwm_slidr.Value = _RoverMovement.pwm;
                        _RoverMovement.RoverMovementStatusUpdater();
                    }
                    else
                    {
                        RoverConsole.ArcEyeAiContentThreadSafe("Executing Same Command ... !!!");
                    }
                }));
            }

            if (state.Offset == JoystickOffset.Buttons0 && state.Value == 128)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_c.IsChecked = true;
                }));
            }
            else if (state.Offset == JoystickOffset.Buttons0 && state.Value == 0)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_c.IsChecked = false;
                }));
            }

            if (state.Offset == JoystickOffset.Buttons1 && state.Value == 128)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_d.IsChecked = true;
                }));
            }
            else if (state.Offset == JoystickOffset.Buttons1 && state.Value == 0)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_d.IsChecked = false;
                }));
            }

            if (state.Offset == JoystickOffset.Buttons2 && state.Value == 128)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_a.IsChecked = true;
                }));
            }
            else if (state.Offset == JoystickOffset.Buttons2 && state.Value == 0)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_a.IsChecked = false;
                }));
            }

            if (state.Offset == JoystickOffset.Buttons3 && state.Value == 128)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_b.IsChecked = true;
                }));
            }
            else if (state.Offset == JoystickOffset.Buttons3 && state.Value == 0)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_b.IsChecked = false;
                }));
            }

            if (state.Offset == JoystickOffset.Buttons4 && state.Value == 128)//high torque
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_l1.IsChecked = true;
                    _RoverMovement.hgh_spd_btn.IsEnabled = true;
                    _RoverMovement.hgh_trq_btn.IsEnabled = false;
                }));
            }

            else if (state.Offset == JoystickOffset.Buttons4 && state.Value == 0)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_l1.IsChecked = false;
                }));
            }

            if (state.Offset == JoystickOffset.Buttons5 && state.Value == 128)//high speed
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_r1.IsChecked = true;
                    _RoverMovement.hgh_spd_btn.IsEnabled = false;
                    _RoverMovement.hgh_trq_btn.IsEnabled = true;
                }));
            }
            else if (state.Offset == JoystickOffset.Buttons5 && state.Value == 0)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_r1.IsChecked = false;
                }));
            }

            if (state.Offset == JoystickOffset.Buttons6 && state.Value == 128)//pwm increase
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_l2.IsChecked = true;
                    if (_RoverMovement.tempPwm <= 80)
                    {
                        _RoverMovement.tempPwm = _RoverMovement.tempPwm + 20;
                        RoverConsole.ArcEyeContentThreadSafe("Speed set to : " + _RoverMovement.tempPwm.ToString());
                    }
                    else
                    {
                        RoverConsole.ArcEyeAiContentThreadSafe("Speed Already Set To The Maximum Limit");
                    }

                }));
            }
            else if (state.Offset == JoystickOffset.Buttons6 && state.Value == 0)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_l2.IsChecked = false;
                }));
            }

            if (state.Offset == JoystickOffset.Buttons7 && state.Value == 128)//pwm decrease
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_r2.IsChecked = true;
                    if (_RoverMovement.tempPwm >= 40)
                    {
                        _RoverMovement.tempPwm = _RoverMovement.tempPwm - 20;
                        RoverConsole.ArcEyeContentThreadSafe("Speed set to : " + _RoverMovement.tempPwm.ToString());
                    }
                    else
                    {
                        RoverConsole.ArcEyeAiContentThreadSafe("Speed Already Set To The Minimum Limit");
                    }
                }));
            }
            else if (state.Offset == JoystickOffset.Buttons7 && state.Value == 0)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_r2.IsChecked = false;
                }));
            }

            if (state.Offset == JoystickOffset.Buttons8 && state.Value == 128)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_08.IsChecked = true;
                }));
            }
            else if (state.Offset == JoystickOffset.Buttons8 && state.Value == 0)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_08.IsChecked = false;
                }));
            }

            if (state.Offset == JoystickOffset.Buttons9 && state.Value == 128)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_09.IsChecked = true;
                }));
            }
            else if (state.Offset == JoystickOffset.Buttons9 && state.Value == 0)
            {
                _RoverMovement.rvr_mvmnt_pnl.Dispatcher.Invoke((Action)(() =>
                {
                    _RoverMovement.rb_09.IsChecked = false;
                }));
            }
        }
    }
    public partial class RoverMovement
    {

        private void pi1Port1ConnectedStatusEventHandler(object sender, EventArgs e)
        {
            _RoverMovement.rvr_mvmnt_pnl.IsEnabled = true;
        }

        private void pi1Port1DisconnectedStatusEvent(object sender, EventArgs e)
        {
            _RoverMovement.rvr_mvmnt_pnl.IsEnabled = false;
            MessageBox.Show("Please Check The Connection Settings in\n'Connection Settings And Maintenance Dock'\n Or Check The Error In : RoverConsole", "pi1Port1 Connection Error");
        }
    }
    public enum RoverAndArmRoverMovement
    {
        Forward, Backward, LeftTurn, RightTurn, Stop
    }
    public class RoverMovementExtra
    {
    }
}
