﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ARC_EYE
{
    /// <summary>
    /// Interaction logic for SettingsModule.xaml
    /// </summary>
    public partial class SettingsModule : UserControl
    {
        public static SettingsModule _SettingsModule = null;
        public static SettingsModule SettingsModuleHandler()
        {
            if (_SettingsModule == null)
            {
                _SettingsModule = new SettingsModule();
            }
            return _SettingsModule;
        }
        public SettingsModule()
        {
            InitializeComponent();
            ConnectorOne.pi1Port1ConnectedStatusEvent += new EventHandler(pi1Port1ConnectedStatusEventHandler);
            ConnectorOne.pi1Port1DisconnectedStatusEvent += new EventHandler(pi1Port1DisconnectedStatusEvent);
        }

        private void pi_1_port_1_btn_Click(object sender, RoutedEventArgs e)
        {
            ConnectorOne.pi1Port1ConnectionEnabler();
        }
    }
}
