﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARC_EYE
{
    public partial class MainWindow
    {
        private void pi1Port1ConnectedStatusEventHandler(object sender, EventArgs e)
        {
            this.cnc_stings_dck.IsExpanded = false;
        }

        private void pi1Port1DisconnectedStatusEvent(object sender, EventArgs e)
        {
            this.cnc_stings_dck.IsExpanded = true;
        }
    }
    class MainWindowExtra
    {
    }
}
