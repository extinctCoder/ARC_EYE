param($rootPath, $toolsPath, $package, $project)

$project.DTE.ItemOperations.Navigate('http://mahapps.com/guides/quick-start.html')
